import heapq

class PuzzleState:
    def __init__(self, board, empty_pos, g, parent=None):
        self.board = board  # Board is a tuple of tuples
        self.empty_pos = empty_pos  # Position of the empty space (row, col)
        self.g = g  # Cost to reach this state from the start state
        self.parent = parent  # Parent state
        self.h = self.manhattan_distance()  # Heuristic value
        self.f = self.g + self.h  # f = g + h

    def manhattan_distance(self):
        """Calculate the Manhattan Distance heuristic."""
        distance = 0
        goal_positions = {(1, 1): (0, 0), (2, 1): (0, 1), (3, 1): (0, 2),
                          (4, 1): (1, 0), (5, 1): (1, 1), (6, 1): (1, 2),
                          (7, 1): (2, 0), (8, 1): (2, 1)}
        for i in range(3):
            for j in range(3):
                value = self.board[i][j]
                if value != 0:
                    goal_i, goal_j = goal_positions[(value, 1)]
                    distance += abs(goal_i - i) + abs(goal_j - j)
        return distance

    def generate_successors(self):
        """Generate successors by sliding tiles into the empty space."""
        successors = []
        row, col = self.empty_pos
        moves = [(-1, 0), (1, 0), (0, -1), (0, 1)]  # Up, Down, Left, Right
        for dr, dc in moves:
            new_row, new_col = row + dr, col + dc
            if 0 <= new_row < 3 and 0 <= new_col < 3:
                new_board = [list(row) for row in self.board]
                new_board[row][col], new_board[new_row][new_col] = new_board[new_row][new_col], new_board[row][col]
                new_state = PuzzleState(tuple(tuple(row) for row in new_board), (new_row, new_col), self.g + 1, self)
                successors.append(new_state)
        return successors

    def __lt__(self, other):
        return self.f < other.f

def a_star_search(start_state, goal_state):
    open_list = []
    heapq.heappush(open_list, (start_state.f, start_state))
    closed_list = set()
    
    while open_list:
        _, current_state = heapq.heappop(open_list)
        
        if current_state.board == goal_state:
            return current_state
        
        closed_list.add(current_state.board)
        
        for successor in current_state.generate_successors():
            if successor.board in closed_list:
                continue
            heapq.heappush(open_list, (successor.f, successor))
    
    return None

def print_solution(state):
    """Print the solution path from the initial state to the goal state."""
    path = []
    while state:
        path.append(state)
        state = state.parent
    path.reverse()
    for step in path:
        print_board(step.board)
        print()

def print_board(board):
    for row in board:
        print(" ".join(str(x) if x != 0 else "_" for x in row))
        
# Initial board configuration
initial_board = (
    (2, 8, 3),
    (1, 6, 4),
    (7, 0, 5)
)
goal_board = (
    (1, 2, 3),
    (4, 5, 6),
    (7, 8, 0)
)

initial_state = PuzzleState(initial_board, (2, 1), 0)
goal_state = goal_board

solution = a_star_search(initial_state, goal_state)

if solution:
    print("Solution found!")
    print_solution(solution)
else:
    print("No solution found.")
